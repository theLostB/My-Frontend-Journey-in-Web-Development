/**
 * @License MIT
 * @copyright LosTBoy 2023 All Right Reserved
 * @author LosTBoy
 */

 'use strict';

 import { error404, updateWeather } from "./app.js";
 const defaultLocation = "#/weather/lat=51.5073219&lon=-01276474" //London
 
 const currentLocation = function () {
   window.navigator.geolocation.getCurrentPosition(res => {
      const { latitude, longitude } = res.coords;

      updateWeather(`lat=${latitude}`, `lon=${longitude}`)
   }, err => {
      window.location.hash = defualtLocation;
   });
 }

 /**
  * @param {string} query Searched query 
  */
 const searchedLocation = query => updateWeather(...query.split("&"));
 const routes = new Map ([
    ["/current-location", currentLocation],
    ["/weather", searchedLocation]
 ])
 // updateWeather("lat=51.5073219", "lon=-01276474")
 const checkHash = function () {
    const requestURL = window.location.hash.slice(1);

    const [route, query] = requestURL.includes ? requestURL.split("?") : [requestURL];

    routes.get(routes) ? routes.get(route)(query) : error404();
 }

 window.addEventListener("hashChange", checkHash);

 window.addEventListener("load", function () {
    if (!window.location.hash) {
        window.location.hash = "#/current-location";
    } else {
        checkHash();

    }
 });
