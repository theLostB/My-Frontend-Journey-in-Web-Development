# animationofcatrat
In this code I have used html ,css for animation.
OUTPUT
In this code I have used html ,css for animation.
![image](https://user-images.githubusercontent.com/105263777/221340945-260babd2-730b-4316-be84-7a386d42b111.png)
