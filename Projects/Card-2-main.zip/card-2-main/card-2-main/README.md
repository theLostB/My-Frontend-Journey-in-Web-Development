# card-2
This is a simple card using html and css.
OUTPUT
![image](https://user-images.githubusercontent.com/105263777/218335070-519397fb-d91a-4fa0-b2f7-89252e4d5ad3.png)
