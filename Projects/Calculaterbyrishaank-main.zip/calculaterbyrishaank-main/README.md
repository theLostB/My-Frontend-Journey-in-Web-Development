# calculaterbyrajeev
this is fully working calculater, using HTML, CSS and basic Java Script.
OUTPUT
![image](https://user-images.githubusercontent.com/105263777/219932650-a9f1a3ee-09b3-4532-8b5d-a77f09b84e71.png)
