


 function myFunction() {
  const menubtn = document.querySelector('#menu-btn');
  const closebtn = document.querySelector('#close-btn');
  const menu = document.querySelector('nav .conatiner ul');
  element.classList.toggle("mystyle");
}