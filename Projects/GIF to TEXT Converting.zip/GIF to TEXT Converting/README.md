# giftotext
gif to text converter using html and css
OUTPUT
![image](https://user-images.githubusercontent.com/105263777/229272596-97bc90e9-7a02-4df1-9bf9-2dbe96d18aba.png)
